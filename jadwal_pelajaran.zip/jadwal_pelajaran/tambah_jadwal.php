<?php
session_start();
include 'koneksi.php';

// Periksa apakah user sudah login dan memiliki hak akses guru
if (!isset($_SESSION['role']) || $_SESSION['role'] !== "guru") {
    header("Location: login.php");
    exit;
}

// Proses penyimpanan data jika form dikirimkan
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_kelas = mysqli_real_escape_string($conn, $_POST['id_kelas']);
    $id_jam_pelajaran = mysqli_real_escape_string($conn, $_POST['id_jam_pelajaran']);
    $id_mapel = mysqli_real_escape_string($conn, $_POST['id_mapel']);
    $id_guru = mysqli_real_escape_string($conn, $_POST['id_guru']);
    $hari = mysqli_real_escape_string($conn, $_POST['hari']);
    
    // Ambil waktu mulai dan selesai dari jam pelajaran
    $jam_query = mysqli_query($conn, "SELECT jam_mulai, jam_selesai FROM jam_pelajaran WHERE id = '$id_jam_pelajaran'");
    $jam_data = mysqli_fetch_assoc($jam_query);
    $jam_mulai = $jam_data['jam_mulai'];
    $jam_selesai = $jam_data['jam_selesai'];

    // Cek apakah ada jadwal yang bertabrakan
    $check_query = "SELECT jp.* FROM jadwal_pelajaran jp
                    JOIN jam_pelajaran j ON jp.id_jam_pelajaran = j.id
                    WHERE jp.id_guru = '$id_guru' 
                    AND jp.hari = '$hari' 
                    AND (
                        (j.jam_mulai < '$jam_selesai' AND j.jam_selesai > '$jam_mulai')
                    )";
    
    $check_result = mysqli_query($conn, $check_query);

    if (mysqli_num_rows($check_result) > 0) {
        echo "<script>alert('Jadwal bertabrakan dengan jadwal yang sudah ada!');</script>";
    } else {
        // Jika tidak ada tabrakan, simpan jadwal
        $query = "INSERT INTO jadwal_pelajaran (id_kelas, id_jam_pelajaran, id_mapel, id_guru, hari) 
                  VALUES ('$id_kelas', '$id_jam_pelajaran', '$id_mapel', '$id_guru', '$hari')";
        
        if (mysqli_query($conn, $query)) {
            echo "<script>alert('Jadwal berhasil ditambahkan!'); window.location='jadwal.php?id_kelas=" . $id_kelas . "';</script>";;
        } else {
            echo "<script>alert('Terjadi kesalahan, coba lagi!');</script>";
        }
    }
}
$id_kelas = $_GET['id_kelas'];
// Ambil data untuk dropdown
$kelas_query = mysqli_query($conn, "SELECT * FROM kelas where id_kelas = $id_kelas");
$jam_query = mysqli_query($conn, "SELECT * FROM jam_pelajaran");
$mapel_query = mysqli_query($conn, "SELECT * FROM mata_pelajaran");
$guru_query = mysqli_query($conn, "SELECT * FROM guru");

$idkelas = isset($_GET['id_kelas']) ? $_GET['id_kelas'] : null;

?>

<!DOCTYPE html>
<html lang="id">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Jadwal</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f5f5f5; margin: 0; padding: 0; }
        .container { width: 50%; margin: 50px auto; background: white; padding: 20px; box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1); }
        h2 { text-align: center; }
        label { font-weight: bold; display: block; margin-top: 10px; }
        select, input { width: 100%; padding: 10px; margin-top: 5px; }
        button { width: 100%; padding: 10px; background-color: #2980b9; color: white; border: none; cursor: pointer; margin-top: 20px; }
        .button { width: 100%; padding: 10px; background-color: #2980b9; color: white; border: none; cursor: pointer; margin-top: 20px; }
        button:hover { background-color: #1c638d; }
    </style>
    <head>
</head>
<body>
    <div class="container">
    <a href="jadwal.php" class="button">Kembali</a>

        <h2>Tambah Jadwal Pelajaran</h2>
        <form method="POST">
            <label for="hari">Hari:</label>
            <select name="hari" required>
                <option value="Senin">Senin</option>
                <option value="Selasa">Selasa</option>
                <option value="Rabu">Rabu</option>
                <option value="Kamis">Kamis</option>
                <option value="Jumat">Jumat</option>
            </select>
            
            <label for="id_kelas">Kelas:</label>
            <select name="id_kelas" required>
                <?php while ($kelas = mysqli_fetch_assoc($kelas_query)) {
                    echo "<option value='{$kelas['id_kelas']}'>{$kelas['nama_kelas']}</option>";
                } ?>
            </select>
            
            <label for="id_jam_pelajaran">Jam Pelajaran:</label>
            <select name="id_jam_pelajaran" required>
                <?php while ($jam = mysqli_fetch_assoc($jam_query)) {
                    echo "<option value='{$jam['id']}'>{$jam['jam_mulai']} - {$jam['jam_selesai']}</option>";
                } ?>
            </select>
            
            <label for="id_mapel">Mata Pelajaran:</label>
            <select name="id_mapel" required>
                <?php while ($mapel = mysqli_fetch_assoc($mapel_query)) {
                    echo "<option value='{$mapel['id_mapel']}'>{$mapel['nama_mapel']}</option>";
                } ?>
            </select>
            
            <label for="id_guru">Guru Pengajar:</label>
            <select name="id_guru" required>
                <?php while ($guru = mysqli_fetch_assoc($guru_query)) {
                    echo "<option value='{$guru['id_guru']}'>{$guru['nama_guru']}</option>";
                } ?>
            </select>
            
            <button type="submit">Simpan Jadwal</button>
        </form>
    </div>
</body>
</html>
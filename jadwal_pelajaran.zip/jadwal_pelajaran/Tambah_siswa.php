<?php
include "koneksi.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['tambah_siswa'])) {
    $nama_siswa = mysqli_real_escape_string($conn, $_POST['nama_siswa']);
    $nis = mysqli_real_escape_string($conn, $_POST['nis']);
    $id_kelas = mysqli_real_escape_string($conn, $_POST['id_kelas']);
    
    $insert_query = "INSERT INTO siswa (nama_siswa, nis, id_kelas) VALUES ('$nama_siswa', '$nis', '$id_kelas')";
    mysqli_query($conn, $insert_query);
    header("Location: kelas.php?id_kelas=$id_kelas");
    exit;
}
?>
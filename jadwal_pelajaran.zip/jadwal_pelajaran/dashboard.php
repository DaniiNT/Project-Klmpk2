<?php 
session_start();
include 'koneksi.php';

// Cek apakah user sudah login dan memiliki role "guru"
if (!isset($_SESSION['role']) || $_SESSION['role'] !== "guru") {
    header("Location: login.php");
    exit;
}

// Ambil total siswa, guru, dan mata pelajaran
$siswa = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM siswa"))['total'];
$guru = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM guru"))['total'];
$mapel = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM mata_pelajaran"))['total'];

// Ambil jumlah siswa per kelas
$query_kelas = "SELECT k.nama_kelas, COUNT(s.id_siswa) AS total_siswa
    FROM kelas k
    LEFT JOIN siswa s ON k.id_kelas = s.id_kelas
    GROUP BY k.nama_kelas
    HAVING COUNT(s.id_siswa) >= 1;";
$result_kelas = mysqli_query($conn, $query_kelas);

$kelas_labels = [];
$kelas_data = [];

while ($row = mysqli_fetch_assoc($result_kelas)) {
    $kelas_labels[] = $row['nama_kelas'];
    $kelas_data[] = $row['total_siswa'];
}

// Ubah data kelas menjadi format JSON untuk JavaScript
$kelas_labels_json = json_encode($kelas_labels);
$kelas_data_json = json_encode($kelas_data);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            display: flex;
            height: 100vh;
            background-color: #f4f4f4;
        }

        /* Sidebar */
        .sidebar {
            width: 250px;
            background: #2c3e50;
            color: white;
            padding-top: 20px;
            position: fixed;
            height: 100%;
        }

        .sidebar h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        .sidebar a {
            display: block;
            padding: 15px;
            color: white;
            text-decoration: none;
            transition: 0.3s;
        }

        .sidebar a:hover {
            background: #34495e;
        }

        /* Konten Utama */
        .main {
            margin-left: 250px;
            padding: 20px;
            width: calc(100% - 250px);
            text-align: center;
        }

        .header {
            background: #2980b9;
            padding: 15px;
            color: white;
            text-align: center;
            font-size: 20px;
            margin-bottom: 20px;
            border-radius: 5px;
        }

        .chart-container {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            display: inline-block;
            margin-bottom: 20px;
        }

        .logout {
            margin-top: 20px;
            text-align: center;
        }

        .logout a {
            display: inline-block;
            padding: 10px 20px;
            background: red;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }

        .logout a:hover {
            background: darkred;
        }
    </style>
</head>
<body>

    <!-- Sidebar -->
    <div class="sidebar">
        <h2>Dashboard</h2>
        <a href="dashboard.php">🏠 Beranda</a>
        <a href="jadwal.php">📅 Jadwal Pelajaran</a>
        <a href="mapel.php">📖 Mata Pelajaran</a>
        <a href="kelas.php">🏫 Kelas</a>
        <a href="logout.php" class="logout">🚪 Logout</a>
    </div>

    <!-- Konten Utama -->
    <div class="main">
        <div class="header">📊 Statistik Sekolah</div>

        <!-- Grafik Jumlah Siswa, Guru, dan Mata Pelajaran -->
        <div class="chart-container">
            <h3>Statistik Umum</h3>
            <canvas id="statistikChart" width="400" height="200"></canvas>
        </div>

        <!-- Grafik Jumlah Siswa per Kelas -->
        <div class="chart-container">
            <h3>Jumlah Siswa per Kelas</h3>
            <canvas id="kelasChart" width="400" height="200"></canvas>
        </div>
    </div>

    <script>
        // Grafik Statistik Umum
        var ctx1 = document.getElementById('statistikChart').getContext('2d');
        new Chart(ctx1, {
            type: 'bar',
            data: {
                labels: ['Siswa', 'Guru', 'Mata Pelajaran'],
                datasets: [{
                    label: 'Jumlah',
                    data: [<?= $siswa ?>, <?= $guru ?>, <?= $mapel ?>],
                    backgroundColor: ['#3498db', '#e74c3c', '#2ecc71']
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: { beginAtZero: true }
                }
            }
        });

        // Grafik Jumlah Siswa per Kelas
        var ctx2 = document.getElementById('kelasChart').getContext('2d');
        new Chart(ctx2, {
            type: 'pie',
            data: {
                labels: <?= $kelas_labels_json ?>,
                datasets: [{
                    label: 'Jumlah Siswa',
                    data: <?= $kelas_data_json ?>,
                    backgroundColor: ['#1abc9c', '#f1c40f', '#e67e22', '#9b59b6', '#34495e']
                }]
            },
            options: {
                responsive: true
            }
        });
    </script>

</body>
</html>

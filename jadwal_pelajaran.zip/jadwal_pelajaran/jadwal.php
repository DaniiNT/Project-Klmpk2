<?php
session_start();
include 'koneksi.php';

// Periksa apakah user sudah login
if (!isset($_SESSION['role']) || $_SESSION['role'] !== "guru") {
    header("Location: login.php");
    exit;
}

// Ambil ID Kelas dari URL, default ke kelas 1 jika tidak ada parameter
$id_kelas = isset($_GET['id_kelas']) ? mysqli_real_escape_string($conn, $_GET['id_kelas']) : 1;

// Ambil Hari dari URL, default ke semua hari jika tidak ada parameter
$hari_filter = isset($_GET['hari']) ? mysqli_real_escape_string($conn, $_GET['hari']) : '';

// Query untuk mengambil jadwal berdasarkan kelas dan hari
$query = "SELECT jp.id_jadwal, jp.hari, jam.jam_mulai, jam.jam_selesai, 
       m.nama_mapel, g.nama_guru 
FROM jadwal_pelajaran jp
JOIN jam_pelajaran jam ON jp.id_jam_pelajaran = jam.id
JOIN mata_pelajaran m ON jp.id_mapel = m.id_mapel
JOIN guru g ON jp.id_guru = g.id_guru
WHERE jp.id_kelas = '$id_kelas'";

if ($hari_filter) {
    $query .= " AND jp.hari = '$hari_filter'";
}

$query .= " GROUP BY jp.id_jadwal, jp.hari, jam.jam_mulai, jam.jam_selesai, 
         m.nama_mapel, g.nama_guru
ORDER BY FIELD(jp.hari, 'Senin','Selasa','Rabu','Kamis','Jumat'), 
         jam.jam_mulai;";

$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jadwal Pelajaran</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
            display: flex;
        }

        /* Sidebar */
        .sidebar {
            width: 250px;
            background: #2c3e50;
            color: white;
            padding-top: 10px;
            position: fixed;
            height: 100%;
        }

        .sidebar h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        .sidebar a {
            display: block;
            padding: 15px;
            color: white;
            text-decoration: none;
            transition: 0.3s;
        }

        .sidebar a:hover {
            background: #34495e;
        }

        /* Konten utama */
        .content {
            margin-left: 250px;
            padding: 20px;
            flex: 1;
        }

        h2 {
            color: white;
            text-align: center;
        }

        /* Form Pilihan Kelas */
        .kelas-selector {
            display: flex;
            justify-content: center;
            margin-bottom: 20px;
        }

        .kelas-selector select,
        .kelas-selector button {
            padding: 10px;
            font-size: 16px;
            margin-left: 10px;
        }

        .kelas-selector button {
            background-color: #2980b9;
            color: white;
            border: none;
            cursor: pointer;
        }

        .kelas-selector button:hover {
            background-color: #2980b9;
        }

        /* Tabel */
        table {
            width: 100%;
            margin: 0 auto;
            border-collapse: collapse;
            background: white;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }

        th, td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: center;
        }

        th {
            background-color: #2980b9;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        .header { 
            background: #2980b9; 
            padding: 15px; 
            color: white; 
            text-align: center; 
            font-size: 20px; 
        }

        .btn {
            display: inline-block;
            padding: 8px 12px;
            margin: 5px;
            text-decoration: none;
            color: white;
            background: #2980b9;
            border-radius: 4px;
            transition: 0.3s;
        }

        .btn:hover {
            background: #2980b9;
        }

        .btn-delete {
            background: #c0392b;
        }

        .btn-delete:hover {
            background: #e74c3c;
        }
    </style>
</head>
<body>

    <!-- Sidebar -->
    <div class="sidebar">
        <h2>Dashboard</h2>
        <a href="dashboard.php">🏠 Beranda</a>
        <a href="jadwal.php">📅 Jadwal Pelajaran</a>
        <a href="mapel.php">📖 Mata Pelajaran</a>
        <a href="kelas.php">🏫 Kelas</a>
        <a href="logout.php" class="logout">🚪 Logout</a>
    </div>

    <!-- Konten Utama -->
    <div class="content">
        <h2 class="header">Jadwal Pelajaran</h2>

        <!-- Form untuk memilih kelas dan hari -->
        <form method="GET" class="kelas-selector">
            <label for="kelas">Pilih Kelas:</label>
            <form method="GET" class="kelas-selector">
    <label for="kelas">Pilih Kelas:</label>
    <select name="id_kelas" id="kelas" onchange="this.form.submit()">
        <?php
        $kelas_query = mysqli_query($conn, "SELECT * FROM kelas");
        while ($kelas = mysqli_fetch_assoc($kelas_query)) {
            $selected = ($kelas['id_kelas'] == $id_kelas) ? "selected" : "";
            echo "<option value='{$kelas['id_kelas']}' $selected>{$kelas['nama_kelas']}</option>";
        }
        ?>
    </select>

    <label for="hari">Pilih Hari:</label>
    <select name="hari" id="hari">
        <option value="">Semua Hari</option>
        <option value="Senin" <?php echo ($hari_filter == 'Senin') ? 'selected' : ''; ?>>Senin</option>
        <option value="Selasa" <?php echo ($hari_filter == 'Selasa') ? 'selected' : ''; ?>>Selasa</option>
        <option value="Rabu" <?php echo ($hari_filter == 'Rabu') ? 'selected' : ''; ?>>Rabu</option>
        <option value="Kamis" <?php echo ($hari_filter == 'Kamis') ? 'selected' : ''; ?>>Kamis</option>
        <option value="Jumat" <?php echo ($hari_filter == 'Jumat') ? 'selected' : ''; ?>>Jumat</option>
    </select>

    <button type="submit">Tampilkan</button>
</form>

<!-- Tombol Tambah Jadwal -->
<a href="tambah_jadwal.php?id_kelas=<?php echo $id_kelas; ?>" class="btn">Tambah Jadwal</a>
        <!-- Tabel Jadwal -->
        <table>
            <tr>
                <th>Hari</th>
                <th>Jam Mulai</th>
                <th>Jam Selesai</th>
                <th>Mata Pelajaran</th>
                <th>Guru</th>
                <th>Aksi</th>
            </tr>
            <?php while ($row = mysqli_fetch_assoc($result)) { ?>
            <tr>
                <td><?php echo $row['hari']; ?></td>
                <td><?php echo $row['jam_mulai']; ?></td>
                <td><?php echo $row['jam_selesai']; ?></td>
                <td><?php echo $row['nama_mapel']; ?></td>
                <td><?php echo $row['nama_guru']; ?></td>
                <td>
                    <a href="edit_jadwal.php?id_jadwal=<?php echo $row['id_jadwal']; ?>" class="btn">✏️ Edit</a>
                    <a href="hapus_jadwal.php?id_jadwal=<?php echo $row['id_jadwal']; ?>" class="btn btn-delete" onclick="return confirm('Yakin ingin menghapus jadwal ini?');">🗑 Hapus</a>
                </td>
            </tr>
            <?php } ?>
        </table>
    </div>

</body>
</html>
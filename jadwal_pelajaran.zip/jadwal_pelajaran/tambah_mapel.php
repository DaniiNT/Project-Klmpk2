<?php 
include 'koneksi.php';

if (isset($_POST['tambah'])) {
    $nama_mapel = $_POST['nama_mapel'];
    $deskripsi = $_POST['deskripsi'];
    $id_guru = $_POST['id_guru'];

    mysqli_query($conn, "INSERT INTO mata_pelajaran (nama_mapel, deskripsi, id_guru) VALUES ('$nama_mapel', '$deskripsi', '$id_guru')");
    header("Location: mapel.php");
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Mata Pelajaran</title>
    <style>
        body { font-family: Arial, sans-serif; text-align: center; background-color: #f4f4f4; }
        form { width: 40%; margin: 20px auto; background: white; padding: 20px; box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1); }
        input, select, textarea, button { width: 100%; padding: 10px; margin: 5px 0; }
        button { background-color: #4CAF50; color: white; border: none; cursor: pointer; }
        button:hover { background-color: #45a049; }
        .btn-back { display: inline-block; padding: 10px; background: red; color: white; text-decoration: none; border-radius: 5px; }
    </style>
</head>
<body>

    <h2>Tambah Mata Pelajaran</h2>
    <a href="mapel.php" class="btn-back">Kembali</a>

    <form method="POST">
        <label>Nama Mata Pelajaran:</label>
        <input type="text" name="nama_mapel" required>
        
        <label>Deskripsi:</label>
        <textarea name="deskripsi" required></textarea>

        <label>Guru Pengajar:</label>
        <select name="id_guru" required>
            <?php
            $guru_query = mysqli_query($conn, "SELECT * FROM guru");
            while ($guru = mysqli_fetch_assoc($guru_query)) {
                echo "<option value='{$guru['id_guru']}'>{$guru['nama_guru']}</option>";
            }
            ?>
        </select>

        <button type="submit" name="tambah">Tambah</button>
    </form>

</body>
</html>

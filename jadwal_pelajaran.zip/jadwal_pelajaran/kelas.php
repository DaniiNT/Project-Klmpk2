<?php
session_start();
include 'koneksi.php';

// Periksa apakah user sudah login
if (!isset($_SESSION['role']) || $_SESSION['role'] !== "guru") {
    header("Location: login.php");
    exit;
}

$id_kelas = isset($_GET['id_kelas']) ? mysqli_real_escape_string($conn, $_GET['id_kelas']) : 1;

// Query untuk mengambil data siswa berdasarkan kelas
$siswa_query = "SELECT s.nama_siswa, k.nama_kelas, s.nis
                FROM siswa s
                JOIN kelas k ON s.id_kelas = k.id_kelas
                WHERE s.id_kelas = '$id_kelas'";
$siswa_result = mysqli_query($conn, $siswa_query);

// Query untuk mengambil data wali kelas
$guru_query = "SELECT g.nama_guru 
               FROM kelas k 
               JOIN guru g ON k.id_wali_guru = g.id_guru 
               WHERE k.id_kelas = '$id_kelas'";



$guru_result = mysqli_query($conn, $guru_query);
$guru = mysqli_fetch_assoc($guru_result);
$nama_guru = $guru ? $guru['nama_guru'] : 'Tidak Diketahui';

// Tambahkan logika untuk menambah siswa
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['tambah_siswa'])) {
    $nama_siswa = mysqli_real_escape_string($conn, $_POST['nama_siswa']);
    $nis = mysqli_real_escape_string($conn, $_POST['nis']);
    $id_kelas = mysqli_real_escape_string($conn, $_POST['id_kelas']);
    
    $insert_query = "INSERT INTO siswa (nama_siswa, nis, id_kelas) VALUES ('$nama_siswa', '$nis', '$id_kelas')";
    mysqli_query($conn, $insert_query);
    header("Location: kelas.php?id_kelas=$id_kelas");
    exit;
}

// Tambahkan logika untuk menghapus siswa
if (isset($_GET['hapus'])) {
    $nis = mysqli_real_escape_string($conn, $_GET['hapus']);
    $delete_query = "DELETE FROM siswa WHERE nis = '$nis'";
    mysqli_query($conn, $delete_query);
    header("Location: kelas.php?id_kelas=$id_kelas");
    exit;
}

// Tambahkan logika untuk mengedit siswa
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_siswa'])) {
    $nama_siswa = mysqli_real_escape_string($conn, $_POST['nama_siswa']);
    $nis = mysqli_real_escape_string($conn, $_POST['nis']);
    $id_kelas = mysqli_real_escape_string($conn, $_POST['id_kelas']);
    
    $update_query = "UPDATE siswa SET nama_siswa = '$nama_siswa' WHERE nis = '$nis'";
    mysqli_query($conn, $update_query);
    header("Location: kelas.php?id_kelas=$id_kelas");
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jadwal Pelajaran</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
            display: flex;
        }

        /* Sidebar */
        .sidebar {
            width: 250px;
            background: #2c3e50;
            color: white;
            padding-top: 10px;
            position: fixed;
            height: 100%;
        }

        .sidebar h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        .sidebar a {
            display: block;
            padding: 15px;
            color: white;
            text-decoration: none;
            transition: 0.3s;
        }

        .sidebar a:hover {
            background: #34495e;
        }

        /* Konten utama */
        .content {
            margin-left: 250px;
            padding: 20px;
            flex: 1;
        }

        h2 {
            color: white;
            text-align: center;
        }

        /* Form Pilihan Kelas */
        .kelas-selector {
            display: flex;
            justify-content: center;
            margin-bottom: 20px;
        }

        .kelas-selector select,
        .kelas-selector button {
            padding: 10px;
            font-size: 16px;
            margin-left: 10px;
        }

        .kelas-selector button {
            background-color: #2980b9;
            color: white;
            border: none;
            cursor: pointer;
        }

        .kelas-selector button:hover {
            background-color: #2980b9;
        }

        /* Tabel */
        table {
            width: 100%;
            margin: 0 auto;
            border-collapse: collapse;
            background: white;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }

        th, td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: center;
        }

        th {
            background-color: #2980b9;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        .btn { padding: 10px; text-decoration: none; display: inline-block; margin: 5px; border-radius: 5px; }
        .header { background: #2980b9; padding: 15px; color: white; text-align: center; font-size: 20px; }
        .btn-blue { background: #2980b9; color: white; }
        .btn-red { background: red; color: white; }
        .tombol-container {
    margin-top: 30px;
    display: flex;
    justify-content: flex-end;
}
    </style>
</head>
<body>

<div class="sidebar">
    <h2>Dashboard</h2>
    <a href="dashboard.php">🏠 Beranda</a>
    <a href="jadwal.php">📅 Jadwal Pelajaran</a>
    <a href="mapel.php">📖 Mata Pelajaran</a>
    <a href="kelas.php">🏫 Kelas</a>
    <a href="logout.php" class="logout">🚪 Logout</a>
</div>

<!-- Konten Utama -->
<div class="content">
    <h2 class="header">Daftar Siswa</h2>
    
    <!-- Form untuk memilih kelas -->
    <form method="GET" class="kelas-selector">
        <label for="kelas">Pilih Kelas:</label>
        <select name="id_kelas" id="kelas">
            <?php
            $kelas_query = mysqli_query($conn, "SELECT * FROM kelas");
            while ($kelas = mysqli_fetch_assoc($kelas_query)) {
                $selected = ($kelas['id_kelas'] == $id_kelas) ? "selected" : "";
                echo "<option value='{$kelas['id_kelas']}' $selected>{$kelas['nama_kelas']}</option>";
            }
            ?>
        </select>
        <button type="submit">Tampilkan</button>

    </form>
    
    <label for="guru"><strong>Nama Wali Kelas:</strong> <?php echo $nama_guru; ?></label>
    <!-- Form untuk menambah siswa baru -->
    <form method="POST" class="kelas-selector"><br>
        <input type="text" name="nama_siswa" placeholder="Nama Siswa" required><br>
        <input type="text" name="nis" placeholder="NIS" required><br>
        <input type="hidden" name="id_kelas" value="<?php echo $id_kelas; ?>"><br>
        <button type="submit" name="tambah_siswa">Tambah Siswa</button><br>
    </form>
    <!-- Tabel Daftar Siswa -->
    <table>
        <tr>
            <th>NIS</th>
            <th>NAMA SISWA</th>
            <th>AKSI</th>
        </tr>
        <?php while ($siswa_row = mysqli_fetch_assoc($siswa_result)) { ?>
            <tr>
                <td><?php echo $siswa_row['nis']; ?></td>
                <td><?php echo $siswa_row['nama_siswa']; ?></td>
                <td>
                    <a href="?id_kelas=<?php echo $id_kelas; ?>&edit=<?php echo $siswa_row['nis']; ?>" class="btn btn-blue">Edit</a>
                    <a href="kelas.php?id_kelas=<?php echo $id_kelas; ?>&hapus=<?php echo $siswa_row['nis']; ?>" class="btn btn-red" onclick="return confirm('Apakah Anda yakin ingin menghapus siswa ini?')">Hapus</a>
                </td>
            </tr>
        <?php } ?>
    </table>

    <?php 
if (isset($_GET['edit'])): 
    $nis_edit = mysqli_real_escape_string($conn, $_GET['edit']);
    $siswa_edit_query = "SELECT * FROM siswa WHERE nis = '$nis_edit'";
    $siswa_edit_result = mysqli_query($conn, $siswa_edit_query);

    // Pastikan query berhasil dieksekusi dan ada hasil
    if ($siswa_edit_result && mysqli_num_rows($siswa_edit_result) > 0) {
        $siswa_edit = mysqli_fetch_assoc($siswa_edit_result);
    } else {
        echo "<p style='color: red;'>Data siswa tidak ditemukan.</p>";
        $siswa_edit = null;
    }
?>
<?php if ($siswa_edit): ?>
    <!-- Form untuk mengedit siswa -->
    <form method="POST" class="kelas-selector"><br><br>
        <input type="text" name="nama_siswa" value="<?php echo htmlspecialchars($siswa_edit['nama_siswa']); ?>" required>
        <input type="hidden" name="nis" value="<?php echo htmlspecialchars($siswa_edit['nis']); ?>">
        <input type="hidden" name="id_kelas" value="<?php echo htmlspecialchars($id_kelas); ?>">
        <button type="submit" name="edit_siswa">Simpan Perubahan</button>
    </form>
<?php endif; ?>
<?php endif; ?>

</div>

</body>
</html>

<?php
session_start();
include 'koneksi.php';

// Periksa apakah user sudah login
if (!isset($_SESSION['role']) || $_SESSION['role'] !== "guru") {
    header("Location: login.php");
    exit;
}

// Periksa apakah ID jadwal telah diterima
if (!isset($_GET['id_jadwal'])) {
    header("Location: jadwal.php");
    exit;
}

$id_jadwal = $_GET['id_jadwal'];
$query = "SELECT * FROM jadwal_pelajaran WHERE id_jadwal = '$id_jadwal'";
$result = mysqli_query($conn, $query);
$jadwal = mysqli_fetch_assoc($result);

if (!$jadwal) {
    header("Location: jadwal.php");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_kelas = $_POST['id_kelas'];
    $id_jam_pelajaran = $_POST['id_jam_pelajaran'];
    $id_mapel = $_POST['id_mapel'];
    $id_guru = $_POST['id_guru'];
    $hari = $_POST['hari'];

    $update_query = "UPDATE jadwal_pelajaran SET id_kelas='$id_kelas', id_jam_pelajaran='$id_jam_pelajaran', id_mapel='$id_mapel', id_guru='$id_guru', hari='$hari' WHERE id_jadwal='$id_jadwal'";
    
    if (mysqli_query($conn, $update_query)) {
        header("Location: jadwal.php?id_kelas=$id_kelas");
        exit;
    } else {
        echo "Terjadi kesalahan: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Jadwal</title>
</head>
<body>
    <style>
        body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    margin: 0;
    padding: 20px;
}

h2 {
    text-align: center;
    color: #333;
}

form {
    background: #fff;
    max-width: 400px;
    margin: 20px auto;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

label {
    font-weight: bold;
    display: block;
    margin: 10px 0 5px;
}

input, select {
    width: 100%;
    padding: 8px;
    margin-bottom: 10px;
    border: 1px solid #ccc;
    border-radius: 4px;
}

button {
    background: #2980b9;
    color: white;
    padding: 10px;
    border: none;
    width: 100%;
    font-size: 16px;
    border-radius: 4px;
    cursor: pointer;
    transition: 0.3s;
}

button:hover {
    background: #2980b9;
}

    </style>
    <h2>Edit Jadwal</h2>
    <form method="POST">
        <label>Hari:</label>
        <input type="text" name="hari" value="<?php echo $jadwal['hari']; ?>" required><br>
        
        <label>Kelas:</label>
        <select name="id_kelas">
            <?php
            $kelas_query = mysqli_query($conn, "SELECT * FROM kelas");
            while ($kelas = mysqli_fetch_assoc($kelas_query)) {
                $selected = ($kelas['id_kelas'] == $jadwal['id_kelas']) ? "selected" : "";
                echo "<option value='{$kelas['id_kelas']}' $selected>{$kelas['nama_kelas']}</option>";
            }
            ?>
        </select><br>
        
        <label>Jam Pelajaran:</label>
        <select name="id_jam_pelajaran">
            <?php
            $jam_query = mysqli_query($conn, "SELECT * FROM jam_pelajaran");
            while ($jam = mysqli_fetch_assoc($jam_query)) {
                $selected = ($jam['id'] == $jadwal['id_jam_pelajaran']) ? "selected" : "";
                echo "<option value='{$jam['id']}' $selected>{$jam['jam_mulai']} - {$jam['jam_selesai']}</option>";
            }
            ?>
        </select><br>
        
        <label>Mata Pelajaran:</label>
        <select name="id_mapel">
            <?php
            $mapel_query = mysqli_query($conn, "SELECT * FROM mata_pelajaran");
            while ($mapel = mysqli_fetch_assoc($mapel_query)) {
                $selected = ($mapel['id_mapel'] == $jadwal['id_mapel']) ? "selected" : "";
                echo "<option value='{$mapel['id_mapel']}' $selected>{$mapel['nama_mapel']}</option>";
            }
            ?>
        </select><br>
        
        <label>Guru:</label>
        <select name="id_guru">
            <?php
            $guru_query = mysqli_query($conn, "SELECT * FROM guru");
            while ($guru = mysqli_fetch_assoc($guru_query)) {
                $selected = ($guru['id_guru'] == $jadwal['id_guru']) ? "selected" : "";
                echo "<option value='{$guru['id_guru']}' $selected>{$guru['nama_guru']}</option>";
            }
            ?>
        </select><br>
        
        <button type="submit">Simpan Perubahan</button>
    </form>
</body>
</html>

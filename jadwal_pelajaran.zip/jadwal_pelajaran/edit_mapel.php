<?php 
include 'koneksi.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $result = mysqli_query($conn, "SELECT * FROM mata_pelajaran WHERE id_mapel = '$id'");
    $data = mysqli_fetch_assoc($result);
}

if (isset($_POST['edit'])) {
    $id_mapel = $_POST['id_mapel'];
    $nama_mapel = $_POST['nama_mapel'];
    $deskripsi = $_POST['deskripsi'];
    $id_guru = $_POST['id_guru'];

    mysqli_query($conn, "UPDATE mata_pelajaran SET nama_mapel='$nama_mapel', deskripsi='$deskripsi', id_guru='$id_guru' WHERE id_mapel='$id_mapel'");
    header("Location: mata_pelajaran.php");
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Mata Pelajaran</title>
    <style>
        body { font-family: Arial, sans-serif; text-align: center; background-color: #f4f4f4; }
        form { width: 40%; margin: 20px auto; background: white; padding: 20px; box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1); }
        input, select, textarea, button { width: 100%; padding: 10px; margin: 5px 0; }
        button { background-color: #4CAF50; color: white; border: none; cursor: pointer; }
        button:hover { background-color: #45a049; }
        .btn-back { display: inline-block; padding: 10px; background: red; color: white; text-decoration: none; border-radius: 5px; }
    </style>
</head>
<body>

    <h2>Edit Mata Pelajaran</h2>
    <a href="mapel.php" class="btn-back">Kembali</a>

    <form method="POST">
        <input type="hidden" name="id_mapel" value="<?php echo $data['id_mapel']; ?>">
        
        <label>Nama Mata Pelajaran:</label>
        <input type="text" name="nama_mapel" value="<?php echo $data['nama_mapel']; ?>" required>
        
        <label>Deskripsi:</label>
        <textarea name="deskripsi" required><?php echo $data['deskripsi']; ?></textarea>

        <label>Guru Pengajar:</label>
        <select name="id_guru" required>
            <?php
            $guru_query = mysqli_query($conn, "SELECT * FROM guru");
            while ($guru = mysqli_fetch_assoc($guru_query)) {
                $selected = ($guru['id_guru'] == $data['id_guru']) ? "selected" : "";
                echo "<option value='{$guru['id_guru']}' $selected>{$guru['nama_guru']}</option>";
            }
            ?>
        </select>

        <button type="submit" name="edit">Simpan Perubahan</button>
    </form>

</body>
</html>

<?php
include "koneksi.php";
if (isset($_GET['confirm']) && $_GET['confirm'] == 'true' && isset($_GET['id'])) {
    $mapel = mysqli_real_escape_string($conn, $_GET['id']);
    $delete_query = "DELETE FROM mata_pelajaran WHERE id_mapel = '$mapel'";
    
    if (mysqli_query($conn, $delete_query)) {
        echo "<script>alert('Mata Pelajaran berhasil dihapus.'); window.location.href = 'mata_pelajaran.php';</script>";
    } else {
        echo "<script>alert('Gagal menghapus mata pelajaran: " . mysqli_error($conn) . "'); window.location.href = 'mapel.php';</script>";
    }
}
?>
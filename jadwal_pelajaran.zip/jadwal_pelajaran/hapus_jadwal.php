<?php
include "koneksi.php";
if (isset($_GET['id_jadwal'])) {
    $nis = mysqli_real_escape_string($conn, $_GET['id_jadwal']);
    $delete_query = "DELETE FROM jadwal_pelajaran WHERE id_jadwal = '$nis'";
    mysqli_query($conn, $delete_query);
    header("Location: jadwal.php");
    exit;
}
?>
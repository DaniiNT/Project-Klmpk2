<?php
include "koneksi.php";

if (isset($_GET['id'])) {
    $mapel = mysqli_real_escape_string($conn, $_GET['id']);
    echo "<script>
        var confirmDelete = confirm('Apakah Anda yakin ingin menghapus mata pelajaran ini?');
        if (confirmDelete) {
            window.location.href = 'hapus_bener.php?confirm=true&id=$mapel';
        } else {
            window.location.href = 'mata_pelajaran.php';
        }
    </script>";
}
?>


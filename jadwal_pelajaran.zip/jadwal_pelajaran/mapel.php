<?php 
session_start();
include 'koneksi.php';

// Periksa apakah user sudah login
if (!isset($_SESSION['role']) || $_SESSION['role'] !== "guru") {
    header("Location: login.php");
    exit;
}

$result = mysqli_query($conn, "SELECT m.*, g.nama_guru FROM mata_pelajaran m 
                               LEFT JOIN guru g ON m.id_guru = g.id_guru");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mata Pelajaran</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: Arial, sans-serif; }
        body { display: flex; height: 100vh; background-color: #f4f4f4; }
       /* Sidebar */
       .sidebar {
            width: 250px;
            background: #2c3e50;
            color: white;
            padding-top: 20px;
            position: fixed;
            height: 100vh;
        }

        .sidebar h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        .sidebar a {
            display: block;
            padding: 15px;
            color: white;
            text-decoration: none;
            transition: 0.3s;
        }

        .sidebar a:hover {
            background: #34495e;
        }
        .main { margin-left: 250px; padding: 20px; width: calc(100% - 250px); }
        .header { background: #2980b9; padding: 15px; color: white; text-align: center; font-size: 20px; }
        table { width: 100%; margin-top: 20px; border-collapse: collapse; background: white; }
        th, td { border: 1px solid #ddd; padding: 10px; text-align: center; }
        th { background-color: #2980b9; color: white; }
        tr:nth-child(even) { background-color: #f2f2f2; }
        .btn { padding: 10px; text-decoration: none; display: inline-block; margin: 5px; border-radius: 5px; }
        .btn-green { background: #4CAF50; color: white; }
        .btn-blue { background: #2980b9; color: white; }
        .btn-red { background: red; color: white; }
        .tombol-container {
    margin-top: 30px;
    display: flex;
    justify-content: flex-end;
}

    </style>
</head>
<body>

    <!-- Sidebar -->
    <div class="sidebar">
        <h2>Dashboard</h2>
        <a href="dashboard.php">🏠 Beranda</a>
    <a href="jadwal.php">📅 Jadwal Pelajaran</a>
    <a href="mapel.php">📖 Mata Pelajaran</a>
    <a href="kelas.php">🏫 Kelas</a>
    <a href="logout.php" class="logout">🚪 Logout</a>
    </div>

    <!-- Konten -->
    <div class="main">
        <div class="header">📚 Data Mata Pelajaran</div>

        <div class="tombol-container">
    <a href="tambah_mapel.php" class="btn btn-blue">Tambah Mata Pelajaran</a>
</div>

        <table>
            <tr>
                <th>Nama</th>
                <th>Deskripsi</th>
                <th>Guru</th>
                <th>Aksi</th>
            </tr>
            <?php while ($row = mysqli_fetch_assoc($result)) { ?>
            <tr>
                <td><?php echo $row['nama_mapel']; ?></td>
                <td><?php echo $row['deskripsi']; ?></td>
                <td><?php echo $row['nama_guru']; ?></td>
                <td>
                    <a href="edit_mapel.php?id=<?php echo $row['id_mapel']; ?>" class="btn btn-blue">Edit</a>
                    <a href="hapus_mapel.php?id=<?php echo $row['id_mapel']; ?>" class="btn btn-red" onclick="return confirm('Hapus mata pelajaran ini?')">Hapus</a>
                </td>
            </tr>
            <?php } ?>
        </table>
    </div>

</body>
</html>
